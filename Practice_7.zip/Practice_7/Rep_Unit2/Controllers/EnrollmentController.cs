﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Rep_Unit2.Models;
using Rep_Unit2.DAL;

namespace Rep_Unit2.Controllers
{
    public class EnrollmentController : Controller
    {
        private UnitOfWork unitOfWork = new UnitOfWork();

        //
        // GET: /Enrollment/

        public ActionResult Index()
        {
            var enrollments = unitOfWork.EnrollmentRepository.Get(includeProperties: "Student,Course");
            return View(enrollments.ToList());
        }

        //
        // GET: /Enrollment/Details/5

        public ActionResult Details(int id = 0)
        {
            Enrollment enrollment = unitOfWork.EnrollmentRepository.GetByID(id);
            return View(enrollment);
        }

        //
        // GET: /Enrollment/Create

        public ActionResult Create()
        {
            var coursesQuery = unitOfWork.CourseRepository.Get(
                orderBy: q => q.OrderBy(d => d.Title));
            var studentsQuery = unitOfWork.StudentRepository.Get(
                orderBy: q => q.OrderBy(d => d.LastName));
            ViewBag.CourseID = new SelectList(coursesQuery, "CourseID", "Title");
            ViewBag.StudentID = new SelectList(studentsQuery, "StudentID", "LastName");
            return View();
        }

        //
        // POST: /Enrollment/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Enrollment enrollment)
        {
            if (ModelState.IsValid)
            {
                unitOfWork.EnrollmentRepository.Insert(enrollment);
                unitOfWork.Save();
                return RedirectToAction("Index");
            }

            var coursesQuery = unitOfWork.CourseRepository.Get(
                orderBy: q => q.OrderBy(d => d.Title));
            var studentsQuery = unitOfWork.StudentRepository.Get(
                orderBy: q => q.OrderBy(d => d.LastName));
            ViewBag.CourseID = new SelectList(coursesQuery, "CourseID", "Title");
            ViewBag.StudentID = new SelectList(studentsQuery, "StudentID", "LastName");
            return View(enrollment);
        }

        //
        // GET: /Enrollment/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Enrollment enrollment = unitOfWork.EnrollmentRepository.GetByID(id);

            var coursesQuery = unitOfWork.CourseRepository.Get(
                orderBy: q => q.OrderBy(d => d.Title));
            var studentsQuery = unitOfWork.StudentRepository.Get(
                orderBy: q => q.OrderBy(d => d.LastName));
            ViewBag.CourseID = new SelectList(coursesQuery, "CourseID", "Title", enrollment.CourseID);
            ViewBag.StudentID = new SelectList(studentsQuery, "StudentID", "LastName", enrollment.StudentID);

            return View(enrollment);
        }

        //
        // POST: /Enrollment/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Enrollment enrollment)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    unitOfWork.EnrollmentRepository.Update(enrollment);
                    unitOfWork.Save();
                    return RedirectToAction("Index");
                }
            }
            catch (DataException /* dex */)
            {
                //Log the error (uncomment dex variable name after DataException and add a line here to write a log.)
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }

            var coursesQuery = unitOfWork.CourseRepository.Get(
                orderBy: q => q.OrderBy(d => d.Title));
            var studentsQuery = unitOfWork.StudentRepository.Get(
                orderBy: q => q.OrderBy(d => d.LastName));
            ViewBag.CourseID = new SelectList(coursesQuery, "CourseID", "Title", enrollment.CourseID);
            ViewBag.StudentID = new SelectList(studentsQuery, "StudentID", "LastName", enrollment.StudentID);

            return View(enrollment);
        }

        //
        // GET: /Enrollment/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Enrollment enrollment = unitOfWork.EnrollmentRepository.GetByID(id);
            return View(enrollment);
        }

        //
        // POST: /Enrollment/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Enrollment enrollment = unitOfWork.EnrollmentRepository.GetByID(id);
            unitOfWork.EnrollmentRepository.Delete(enrollment);
            unitOfWork.Save();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            unitOfWork.Dispose();
            base.Dispose(disposing);
        }
    }
}